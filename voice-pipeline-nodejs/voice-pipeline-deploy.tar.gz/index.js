import express from 'express';
import { WebSocketServer } from 'ws';
import { createServer } from 'http';
import { readFileSync } from 'fs';
import WebSocket from 'ws';

// Load environment variables from .env file
const envFile = readFileSync('.env', 'utf8');
const env = {};
envFile.split('\n').forEach(line => {
  const [key, value] = line.split('=');
  if (key && value) env[key.trim()] = value.trim();
});

const app = express();
const server = createServer(app);
const wss = new WebSocketServer({ server, path: '/stream' });

const PORT = env.PORT || 8001;

// Health check endpoint
app.get('/health', (req, res) => {
  res.json({
    status: 'healthy',
    service: 'voice-pipeline',
    uptime: process.uptime()
  });
});

/**
 * Voice Pipeline Class
 * Manages the complete voice conversation flow with intelligent turn-taking
 */
class VoicePipeline {
  constructor(twilioWs, callParams) {
    this.twilioWs = twilioWs;
    this.callId = callParams.callId;
    this.userId = callParams.userId;
    this.personaId = callParams.personaId;
    this.callPretext = callParams.callPretext || ''; // e.g., "Save me from a bad date"

    // Persona metadata (will be fetched from database)
    this.personaName = null;
    this.voiceId = null;
    this.systemPrompt = null;
    this.smartMemory = null;

    // Service connections
    this.deepgramWs = null;
    this.elevenLabsWs = null;

    // State
    this.conversationHistory = [];
    this.transcriptSegments = [];
    this.lastSpeechTime = 0;
    this.isSpeaking = false;
    this.isEvaluating = false;
    this.streamSid = null;
    this.silenceTimer = null;
    this.evaluationCount = 0;

    // Turn-taking config
    this.config = {
      shortSilenceMs: 500,       // Ignore pauses shorter than this
      llmEvalThresholdMs: 1200,  // Trigger LLM eval after this silence
      forceResponseMs: 3000,     // Force response after this silence
      maxEvaluations: 2          // Max LLM evals before forcing
    };

    console.log(`[VoicePipeline ${this.callId}] Initialized`, callParams);
  }

  /**
   * Fetch persona metadata from database
   * Fetches: name, voice_id, system_prompt, smart_memory
   */
  async fetchPersonaMetadata() {
    try {
      console.log(`[VoicePipeline ${this.callId}] Fetching persona metadata for ${this.personaId}...`);

      const response = await fetch(`${env.VULTR_DB_API_URL}/query`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${env.VULTR_DB_API_KEY}`  // Fixed: Changed from X-API-Key to Authorization: Bearer
        },
        body: JSON.stringify({
          sql: `
            SELECT p.name, p.core_system_prompt, p.default_voice_id,
                   upr.custom_system_prompt, upr.voice_id
            FROM personas p
            LEFT JOIN user_persona_relationships upr
              ON upr.persona_id = p.id AND upr.user_id = $1
            WHERE p.id = $2
          `,
          params: [this.userId, this.personaId]
        })
      });

      console.log(`[VoicePipeline ${this.callId}] Database response status: ${response.status}`);

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`Database query failed: ${response.status} - ${errorText}`);
      }

      const result = await response.json();
      console.log(`[VoicePipeline ${this.callId}] Database result:`, JSON.stringify(result, null, 2));

      if (result.rows && result.rows.length > 0) {
        const row = result.rows[0];
        this.personaName = row.name || 'Brad';
        // Use custom voice if set, otherwise use persona's default voice
        this.voiceId = row.voice_id || row.default_voice_id || 'pNInz6obpgDQGcFmaJgB';
        // Use custom system prompt if set, otherwise use persona's core prompt
        this.systemPrompt = row.custom_system_prompt || row.core_system_prompt ||
          'You are a supportive friend who keeps it real. Be conversational, direct, and encouraging. Keep responses SHORT (1-2 sentences max) for natural conversation flow.';
        // Note: smart_memory column doesn't exist in current schema - will be added later for static relationship context
        this.smartMemory = '';

        console.log(`[VoicePipeline ${this.callId}] ✅ Loaded persona successfully:`, {
          name: this.personaName,
          voiceId: this.voiceId,
          systemPromptLength: this.systemPrompt.length,
          hasCallPretext: !!this.callPretext
        });
      } else {
        console.warn(`[VoicePipeline ${this.callId}] ⚠️  Persona not found in database, using defaults`);
        this.personaName = 'Brad';
        this.voiceId = 'pNInz6obpgDQGcFmaJgB';
        this.systemPrompt = 'You are Brad, a supportive bro who keeps it real. Be conversational, direct, and encouraging. Keep responses SHORT (1-2 sentences max) for natural conversation flow.';
        this.smartMemory = '';
      }
    } catch (error) {
      console.error(`[VoicePipeline ${this.callId}] ❌ Failed to fetch persona metadata:`, error);
      console.error(`[VoicePipeline ${this.callId}] Error stack:`, error.stack);
      // Use defaults on error
      this.personaName = 'Brad';
      this.voiceId = 'pNInz6obpgDQGcFmaJgB';
      this.systemPrompt = 'You are Brad, a supportive bro who keeps it real. Be conversational, direct, and encouraging. Keep responses SHORT (1-2 sentences max) for natural conversation flow.';
      this.smartMemory = '';
    }
  }

  /**
   * Start the voice pipeline
   */
  async start() {
    try {
      console.log(`[VoicePipeline ${this.callId}] Starting...`);

      // STEP 1: Fetch persona metadata from database
      await this.fetchPersonaMetadata();

      // STEP 2: Connect to Deepgram STT
      await this.connectDeepgram();

      // STEP 3: Connect to ElevenLabs TTS (using persona's voiceId)
      await this.connectElevenLabs();

      console.log(`[VoicePipeline ${this.callId}] All services connected`);

      // STEP 4: Send initial greeting
      await this.speak("Hey! Sorry it took me a minute to get to you!");

    } catch (error) {
      console.error(`[VoicePipeline ${this.callId}] Failed to start:`, error);
      throw error;
    }
  }

  /**
   * Connect to Deepgram STT
   */
  async connectDeepgram() {
    return new Promise((resolve, reject) => {
      console.log(`[VoicePipeline ${this.callId}] Connecting to Deepgram...`);

      const deepgramUrl = 'wss://api.deepgram.com/v1/listen?model=nova-3&encoding=mulaw&sample_rate=8000';

      this.deepgramWs = new WebSocket(deepgramUrl, {
        headers: {
          'Authorization': `Token ${env.DEEPGRAM_API_KEY}`
        }
      });

      this.deepgramWs.on('open', () => {
        console.log(`[VoicePipeline ${this.callId}] Deepgram connected`);
        resolve();
      });

      this.deepgramWs.on('message', (data) => {
        try {
          const response = JSON.parse(data.toString());
          const transcript = response.channel?.alternatives?.[0]?.transcript;
          if (transcript && transcript.trim()) {
            console.log(`[VoicePipeline ${this.callId}] User said:`, transcript);
            this.handleTranscriptSegment(transcript);
          }
        } catch (error) {
          console.error(`[VoicePipeline ${this.callId}] Error parsing Deepgram response:`, error);
        }
      });

      this.deepgramWs.on('error', (error) => {
        console.error(`[VoicePipeline ${this.callId}] Deepgram error:`, error);
        reject(error);
      });

      this.deepgramWs.on('close', () => {
        console.log(`[VoicePipeline ${this.callId}] Deepgram connection closed`);
      });

      setTimeout(() => reject(new Error('Deepgram connection timeout')), 5000);
    });
  }

  /**
   * Connect to ElevenLabs TTS
   */
  async connectElevenLabs() {
    return new Promise((resolve, reject) => {
      console.log(`[VoicePipeline ${this.callId}] Connecting to ElevenLabs with voice: ${this.voiceId}...`);

      const wsUrl = `wss://api.elevenlabs.io/v1/text-to-speech/${this.voiceId}/stream-input?model_id=eleven_turbo_v2_5&output_format=ulaw_8000`;

      this.elevenLabsWs = new WebSocket(wsUrl, {
        headers: {
          'xi-api-key': env.ELEVENLABS_API_KEY
        }
      });

      this.elevenLabsWs.on('open', () => {
        console.log(`[VoicePipeline ${this.callId}] ElevenLabs connected`);

        // Send initial config
        this.elevenLabsWs.send(JSON.stringify({
          text: ' ',
          voice_settings: {
            stability: 0.5,
            similarity_boost: 0.75,
            style: 0.0,
            use_speaker_boost: true
          },
          generation_config: {
            chunk_length_schedule: [120, 160, 250, 290]
          }
        }));

        resolve();
      });

      this.elevenLabsWs.on('message', (data) => {
        try {
          const message = JSON.parse(data.toString());

          if (message.audio) {
            const audioBuffer = Buffer.from(message.audio, 'base64');
            this.sendAudioToTwilio(audioBuffer);
          }

          if (message.isFinal) {
            console.log(`[VoicePipeline ${this.callId}] ElevenLabs finished speaking`);
            this.finishSpeaking();
          }
        } catch (error) {
          // Binary audio data
          this.sendAudioToTwilio(data);
        }
      });

      this.elevenLabsWs.on('error', (error) => {
        console.error(`[VoicePipeline ${this.callId}] ElevenLabs error:`, error);
      });

      this.elevenLabsWs.on('close', () => {
        console.log(`[VoicePipeline ${this.callId}] ElevenLabs connection closed`);
      });

      setTimeout(() => reject(new Error('ElevenLabs connection timeout')), 5000);
    });
  }

  /**
   * Handle incoming transcript segment from Deepgram
   */
  handleTranscriptSegment(transcript) {
    // If AI was speaking and user interrupted
    if (this.isSpeaking) {
      console.log(`[VoicePipeline ${this.callId}] User interrupted!`);
      // TODO: Stop TTS playback
      this.isSpeaking = false;
      this.transcriptSegments = [];
      this.evaluationCount = 0;
    }

    // Add to transcript segments
    this.transcriptSegments.push({
      text: transcript,
      timestamp: Date.now()
    });

    this.lastSpeechTime = Date.now();

    // Reset silence timer
    this.resetSilenceTimer();
  }

  /**
   * Reset silence timer
   */
  resetSilenceTimer() {
    if (this.silenceTimer) {
      clearTimeout(this.silenceTimer);
    }

    // Schedule silence check after LLM eval threshold
    this.silenceTimer = setTimeout(() => {
      this.onSilenceDetected();
    }, this.config.llmEvalThresholdMs);
  }

  /**
   * Detect silence and trigger appropriate action
   */
  onSilenceDetected() {
    const silenceDuration = Date.now() - this.lastSpeechTime;

    console.log(`[VoicePipeline ${this.callId}] Silence detected: ${silenceDuration}ms`);

    // Short silence - just a natural pause, keep listening
    if (silenceDuration < this.config.shortSilenceMs) {
      return;
    }

    // LLM evaluation threshold reached
    if (silenceDuration >= this.config.llmEvalThresholdMs &&
        this.evaluationCount < this.config.maxEvaluations &&
        !this.isEvaluating) {
      this.triggerTurnEvaluation();
      return;
    }

    // Force response after maximum wait time
    if (silenceDuration >= this.config.forceResponseMs) {
      console.log(`[VoicePipeline ${this.callId}] Force response timeout`);
      this.triggerResponse('force_timeout');
    }
  }

  /**
   * Trigger turn evaluation (heuristic + LLM) to determine if user is done speaking
   * This is ONLY turn detection - does NOT trigger AI response generation yet
   */
  async triggerTurnEvaluation() {
    this.isEvaluating = true;
    this.evaluationCount++;

    const currentTranscript = this.getPartialTranscript();
    console.log(`[VoicePipeline ${this.callId}] Evaluating turn (attempt ${this.evaluationCount}): "${currentTranscript}"`);

    const decision = await this.evaluateConversationalCompleteness(currentTranscript);

    console.log(`[VoicePipeline ${this.callId}] Turn Decision: ${decision}`);

    this.isEvaluating = false;

    if (decision === 'RESPOND') {
      // User has finished speaking - NOW we can send the full transcript to AI for response generation
      this.triggerResponse('turn_complete');
    } else {
      // WAIT - user is still speaking, schedule next check
      this.silenceTimer = setTimeout(() => {
        this.onSilenceDetected();
      }, this.config.llmEvalThresholdMs);
    }
  }

  /**
   * Combined heuristic + LLM evaluation with heuristic override
   */
  async evaluateConversationalCompleteness(transcript) {
    // First check heuristic - it's fast and catches obvious cases
    const heuristicDecision = this.heuristicTurnEvaluation(transcript);

    // If heuristic says RESPOND (obvious complete statement/question), trust it
    if (heuristicDecision === 'RESPOND') {
      console.log(`[VoicePipeline ${this.callId}] Heuristic override: RESPOND`);
      return 'RESPOND';
    }

    // If heuristic says WAIT (obvious incomplete), trust it
    if (heuristicDecision === 'WAIT') {
      console.log(`[VoicePipeline ${this.callId}] Heuristic override: WAIT`);
      return 'WAIT';
    }

    // Only use LLM for unclear cases
    try {
      const prompt = `Analyze if the user has finished speaking in a natural phone conversation:

User said: "${transcript}"

RESPOND immediately if:
- Complete question (e.g., "did you get the invoice?", "how are you?")
- Complete statement with clear intent
- Greeting or acknowledgment (e.g., "thanks", "okay", "got it")
- Natural conversation turn-ending

WAIT only if:
- Trailing "um", "uh", "so", "and then", "but"
- Mid-sentence pause (clearly incomplete thought)
- Building up to something ("I was thinking..." with nothing after)

Default to RESPOND unless clearly incomplete.

Answer with ONE word only: WAIT, RESPOND, or UNCLEAR

Answer:`;

      const response = await fetch('https://api.cerebras.ai/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${env.CEREBRAS_API_KEY}`
        },
        body: JSON.stringify({
          model: 'llama3.1-8b',
          messages: [{ role: 'user', content: prompt }],
          max_tokens: 10,
          temperature: 0.3,
          stream: false
        })
      });

      const data = await response.json();
      const decision = data.choices[0]?.message?.content?.trim().toUpperCase();

      if (decision.includes('RESPOND')) return 'RESPOND';
      if (decision.includes('WAIT')) return 'WAIT';
      return 'RESPOND'; // Default to RESPOND for UNCLEAR

    } catch (error) {
      console.error(`[VoicePipeline ${this.callId}] Turn evaluation failed:`, error);
      return 'RESPOND'; // Default to responding on error
    }
  }

  /**
   * Semantic-based turn evaluation (inspired by OpenAI's semantic_vad)
   * Analyzes linguistic completeness rather than just word counts
   */
  heuristicTurnEvaluation(transcript) {
    const text = transcript.trim().toLowerCase();
    const words = text.split(/\s+/).filter(w => w.length > 0);

    if (words.length === 0) return 'WAIT';

    const lastWord = words[words.length - 1];
    const firstWord = words[0];

    // 1. WAIT indicators - obvious incompleteness
    const fillerEndings = ['um', 'uh', 'er', 'ah', 'hmm'];
    if (fillerEndings.includes(lastWord)) return 'WAIT';

    const conjunctionEndings = ['and', 'but', 'or', 'so', 'because', 'since', 'while', 'although'];
    if (conjunctionEndings.includes(lastWord)) return 'WAIT';

    const prepositionEndings = ['to', 'in', 'on', 'at', 'for', 'with', 'about', 'from'];
    if (prepositionEndings.includes(lastWord)) return 'WAIT';

    const articleEndings = ['a', 'an', 'the'];
    if (articleEndings.includes(lastWord)) return 'WAIT';

    // Incomplete phrase patterns
    if (text.endsWith('i was') || text.endsWith('i am') || text.endsWith('i will') ||
        text.endsWith('you were') || text.endsWith('you are') || text.endsWith('that is')) {
      return 'WAIT';
    }

    // 2. RESPOND indicators - clear semantic completeness

    // Question patterns - complete questions should respond
    const questionStarts = ['what', 'where', 'when', 'who', 'why', 'how', 'can', 'could',
                           'would', 'should', 'did', 'do', 'does', 'is', 'are', 'was', 'were'];
    if (questionStarts.includes(firstWord) && words.length >= 3) {
      return 'RESPOND'; // e.g., "how are you", "did you get it"
    }

    // Imperative/request patterns
    const imperativeStarts = ['please', 'let', 'go', 'send', 'give', 'show', 'tell'];
    if (imperativeStarts.includes(firstWord) && words.length >= 2) {
      return 'RESPOND'; // e.g., "please send it", "tell me"
    }

    // Acknowledgments and affirmations
    const acknowledgments = ['yeah', 'yes', 'yep', 'okay', 'ok', 'sure', 'alright', 'right',
                            'thanks', 'thank you', 'got it', 'i see', 'no problem'];
    if (acknowledgments.includes(text) || acknowledgments.some(ack => text === ack)) {
      return 'RESPOND';
    }

    // Complete statements with subject-verb-object structure (rough heuristic)
    // If contains pronouns + verbs + reasonable length, likely complete
    const pronouns = ['i', 'you', 'he', 'she', 'it', 'we', 'they'];
    const commonVerbs = ['is', 'are', 'was', 'were', 'have', 'has', 'had', 'will', 'would',
                        'can', 'could', 'do', 'does', 'did', 'get', 'got', 'want', 'need',
                        'think', 'know', 'see', 'said', 'make', 'go', 'send', 'sent'];

    const hasPronoun = words.some(w => pronouns.includes(w));
    const hasVerb = words.some(w => commonVerbs.includes(w));

    if (hasPronoun && hasVerb && words.length >= 4) {
      return 'RESPOND'; // e.g., "i sent you the invoice"
    }

    // 3. Default to UNCLEAR for edge cases
    return 'UNCLEAR';
  }

  /**
   * Trigger full AI response generation
   * This is called ONLY AFTER turn detection has decided the user is done speaking
   * The full user transcript is now sent to the chatbot flow for response generation
   */
  async triggerResponse(reason) {
    console.log(`[VoicePipeline ${this.callId}] User finished speaking (reason: ${reason}). Sending full transcript to AI...`);

    // Clear silence timer
    if (this.silenceTimer) {
      clearTimeout(this.silenceTimer);
      this.silenceTimer = null;
    }

    // Get FINAL complete user transcript (accumulated from all segments)
    const userMessage = this.getPartialTranscript();
    console.log(`[VoicePipeline ${this.callId}] Full user transcript: "${userMessage}"`);

    // Add to conversation history
    this.conversationHistory.push({
      role: 'user',
      content: userMessage
    });

    // Reset for next turn
    this.transcriptSegments = [];
    this.evaluationCount = 0;

    // Generate AI response using the COMPLETE user message
    await this.generateResponse();
  }

  /**
   * Get partial transcript for evaluation
   */
  getPartialTranscript() {
    return this.transcriptSegments
      .map(seg => seg.text)
      .join(' ')
      .trim();
  }

  /**
   * Generate AI response using Cerebras
   */
  async generateResponse() {
    try {
      console.log(`[VoicePipeline ${this.callId}] Generating response...`);

      // Build system prompt with persona configuration, smartMemory, and callPretext
      let systemPrompt = this.systemPrompt;

      // Add smartMemory if available (configured relationships/behavior)
      if (this.smartMemory) {
        systemPrompt += `\n\nRELATIONSHIP CONTEXT:\n${this.smartMemory}`;
      }

      // Add callPretext if available (reason for the call, e.g., "Save me from a bad date")
      if (this.callPretext) {
        systemPrompt += `\n\nCALL CONTEXT: The user requested this call for the following reason: "${this.callPretext}". Keep this context in mind and be helpful with their situation.`;
      }

      const messages = [
        {
          role: 'system',
          content: systemPrompt
        },
        ...this.conversationHistory.slice(-10)
      ];

      const response = await fetch('https://api.cerebras.ai/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${env.CEREBRAS_API_KEY}`
        },
        body: JSON.stringify({
          model: 'llama3.1-8b',
          messages: messages,
          max_tokens: 150,
          temperature: 0.7,
          stream: false
        })
      });

      const data = await response.json();
      const aiResponse = data.choices[0]?.message?.content;

      if (aiResponse) {
        console.log(`[VoicePipeline ${this.callId}] AI says:`, aiResponse);
        this.conversationHistory.push({
          role: 'assistant',
          content: aiResponse
        });

        await this.speak(aiResponse);
      }
    } catch (error) {
      console.error(`[VoicePipeline ${this.callId}] Failed to generate response:`, error);
      await this.speak("Sorry bro, I lost my train of thought. What were you saying?");
    }
  }

  /**
   * Speak text using ElevenLabs TTS
   */
  async speak(text) {
    // Reconnect if disconnected
    if (!this.elevenLabsWs || this.elevenLabsWs.readyState !== WebSocket.OPEN) {
      console.log(`[VoicePipeline ${this.callId}] ElevenLabs disconnected, reconnecting...`);
      await this.connectElevenLabs();
    }

    console.log(`[VoicePipeline ${this.callId}] Speaking:`, text);
    this.isSpeaking = true;

    // Send text to ElevenLabs
    this.elevenLabsWs.send(JSON.stringify({
      text: text,
      try_trigger_generation: true
    }));

    // Send flush to complete generation
    this.elevenLabsWs.send(JSON.stringify({
      text: ''
    }));
  }

  /**
   * Mark AI as done speaking, ready for next turn
   */
  finishSpeaking() {
    console.log(`[VoicePipeline ${this.callId}] Finished speaking, ready for user input`);
    this.isSpeaking = false;
  }

  /**
   * Send audio to Twilio
   */
  sendAudioToTwilio(audioBuffer) {
    if (!this.streamSid) {
      console.warn(`[VoicePipeline ${this.callId}] No streamSid yet, skipping audio`);
      return;
    }

    const payload = audioBuffer.toString('base64');

    this.twilioWs.send(JSON.stringify({
      event: 'media',
      streamSid: this.streamSid,
      media: {
        payload: payload
      }
    }));
  }

  /**
   * Handle incoming audio from Twilio
   */
  handleTwilioMedia(audioPayload) {
    // Forward to Deepgram only when not speaking
    if (this.deepgramWs && !this.isSpeaking) {
      const audioBuffer = Buffer.from(audioPayload, 'base64');
      this.deepgramWs.send(audioBuffer);
    }
  }

  /**
   * Cleanup resources
   */
  cleanup() {
    console.log(`[VoicePipeline ${this.callId}] Cleaning up...`);

    if (this.silenceTimer) {
      clearTimeout(this.silenceTimer);
      this.silenceTimer = null;
    }

    if (this.deepgramWs) {
      this.deepgramWs.close();
      this.deepgramWs = null;
    }

    if (this.elevenLabsWs) {
      this.elevenLabsWs.close();
      this.elevenLabsWs = null;
    }
  }
}

// WebSocket connection handler
wss.on('connection', async (twilioWs, req) => {
  console.log('[Voice Pipeline] New WebSocket connection from Twilio');

  let pipeline = null;

  twilioWs.on('message', async (data) => {
    try {
      const message = JSON.parse(data.toString());

      if (message.event === 'start') {
        console.log('[Voice Pipeline] Received START message from Twilio');

        const callId = message.start.customParameters?.callId || 'unknown';
        const userId = message.start.customParameters?.userId || 'unknown';
        const personaId = message.start.customParameters?.personaId || 'brad_001';
        const callPretext = message.start.customParameters?.callPretext || '';

        console.log('[Voice Pipeline] Call params:', { callId, userId, personaId, callPretext });

        const streamSid = message.start.streamSid;

        pipeline = new VoicePipeline(twilioWs, { callId, userId, personaId, callPretext });
        pipeline.streamSid = streamSid;

        await pipeline.start();
      }

      else if (message.event === 'media' && pipeline) {
        const audioPayload = message.media.payload;
        pipeline.handleTwilioMedia(audioPayload);
      }

      else if (message.event === 'stop') {
        console.log('[Voice Pipeline] Received STOP message from Twilio');
        if (pipeline) {
          pipeline.cleanup();
        }
      }

    } catch (error) {
      console.error('[Voice Pipeline] Error processing Twilio message:', error);
    }
  });

  twilioWs.on('close', () => {
    console.log('[Voice Pipeline] Twilio WebSocket closed');
    if (pipeline) {
      pipeline.cleanup();
    }
  });

  twilioWs.on('error', (error) => {
    console.error('[Voice Pipeline] Twilio WebSocket error:', error);
  });
});

server.listen(PORT, () => {
  console.log(`✅ Voice Pipeline running on port ${PORT}`);
  console.log(`   WebSocket: ws://localhost:${PORT}/stream`);
  console.log(`   Health: http://localhost:${PORT}/health`);
});
